//oppgave 1
var riktigTall = Math.round(Math.random() * 100);
var inputTall = parseInt(prompt("Gjett tallet (mellom 0 og 100):"));

while (true) {
    if (inputTall < riktigTall) {
        inputTall = parseInt(prompt("tallen er er høyere:"));
    } else if (inputTall > riktigTall) {
        inputTall = parseInt(prompt(" tallen er mindre:"));
    } else {
        alert("Gratulerer!");
        break;
    }
}

//oppgave 2

for (var i = 0; i < 10; i++) {

    var line = 5; 
    
    for (var j = 0; j < 10; j++) {
        line += j;
    }
    console.log(line);
    document.write(`<p${i}>0123456789</p${i}><br>`); 
 
}





